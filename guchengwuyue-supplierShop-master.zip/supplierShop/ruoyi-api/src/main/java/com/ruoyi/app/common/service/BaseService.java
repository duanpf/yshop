package com.ruoyi.app.common.service;

import com.baomidou.mybatisplus.extension.service.IService;


public interface BaseService<T> extends IService<T> {

}
