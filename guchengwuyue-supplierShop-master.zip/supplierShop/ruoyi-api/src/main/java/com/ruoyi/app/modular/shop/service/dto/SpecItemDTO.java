package com.ruoyi.app.modular.shop.service.dto;

import lombok.Data;

/**
 * @ClassName SpecItemDTO
 * @Author hupeng <610796224@qq.com>
 * @Date 2019/9/9
 **/

@Data
public class SpecItemDTO {
    private int itemId;
    private String item;
}
