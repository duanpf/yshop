package com.ruoyi.app.common.constant;


public interface CacheKey {

}
