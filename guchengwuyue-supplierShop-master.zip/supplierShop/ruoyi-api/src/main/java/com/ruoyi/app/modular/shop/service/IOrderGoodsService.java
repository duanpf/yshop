package com.ruoyi.app.modular.shop.service;




import com.baomidou.mybatisplus.extension.service.IService;
import com.ruoyi.app.common.persistence.model.StoreOrderGoods;


public interface IOrderGoodsService extends IService<StoreOrderGoods> {

}
