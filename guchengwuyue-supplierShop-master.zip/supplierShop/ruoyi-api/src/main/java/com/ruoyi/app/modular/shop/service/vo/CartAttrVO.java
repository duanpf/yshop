package com.ruoyi.app.modular.shop.service.vo;

import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

@Data
public class CartAttrVO {
    private String specKey;
    private int goodsNum;






}
