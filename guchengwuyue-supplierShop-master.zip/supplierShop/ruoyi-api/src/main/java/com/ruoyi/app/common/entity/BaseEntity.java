package com.ruoyi.app.common.entity;

import io.swagger.annotations.ApiModel;

import java.io.Serializable;


@ApiModel("BaseEntity")
public abstract class BaseEntity implements Serializable{
}
